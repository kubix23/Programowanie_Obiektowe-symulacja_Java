import organisms.Human;
import view.Init;
import view.Logs;
import view.Window_game;
import world.SaveLoad;
import world.World;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        Init a = new Init();
    }
}
