package view.lisener;

public interface MoveListener {
    void isMoved(boolean is);
}
