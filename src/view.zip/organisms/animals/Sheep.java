package organisms.animals;

import organisms.Animals;
import world.World;

public class Sheep extends Animals {
    public Sheep(int posX, int posY, World world) {
        super("Owca",4,4,posX,posY,"O",0,world);
    }
}
