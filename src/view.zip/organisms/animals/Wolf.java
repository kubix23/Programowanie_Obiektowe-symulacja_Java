package organisms.animals;

import organisms.Animals;
import world.World;

public class Wolf extends Animals {

    public Wolf(int posX, int posY, World world){
        super("Wilk",9,5,posX,posY,"W",0,world);
    }

}
